import faiss
import numpy as np
import pandas as pd
import ast
from sentence_transformers import SentenceTransformer

def load_embeddings(embedding_str):
    try:
        # 1. Remove leading/trailing whitespace
        fixed = embedding_str.strip()

        # 2. Remove outer brackets if they exist
        if fixed.startswith('[') and fixed.endswith(']'):
            fixed = fixed[1:-1] # Remove the first and last character

        # 3. Replace any sequence of one or more spaces with a single comma
        # This handles cases like " 0.1  0.2" -> "0.1,0.2"
        fixed = ','.join(fixed.split())

        # 4. Re-add the outer brackets to form a valid list literal
        fixed = f"[{fixed}]"
        
        return np.array(ast.literal_eval(fixed))
    except Exception as e:
        print("Hatalı satır:", embedding_str)
        raise e

# The rest of your RETRIEVAL AND GENERATE LAYER code remains the same:
# CSV'yi oku ve embedding'leri dönüştür
df = pd.read_csv("RAG/answers_with_embeddings.csv")
df["student_emb"] = df["student_emb"].apply(load_embeddings)

# Embedding modeli
model = SentenceTransformer("sentence-transformers/paraphrase-MiniLM-L6-v2")

# FAISS index
student_embeddings = np.vstack(df["student_emb"].values)
index = faiss.IndexFlatL2(student_embeddings.shape[1])
index.add(student_embeddings)

# Benzer cevapları getir
def get_similar_answers(new_answer, top_k=3):
    new_emb = model.encode(new_answer)
    D, I = index.search(np.array([new_emb]), top_k)
    return df.iloc[I[0]], new_emb

# Prompt üret
def generate_feedback_prompt(new_answer, similar_answers_df):
    context = "\n\n".join([
        f"Öğrenci Cevabı: {row.student_answer}\nPuan: {row.score}" for _, row in similar_answers_df.iterrows()
    ])
    prompt = f"""
Sen bir hukuk sınavı değerlendiricisisin.
Yeni öğrenci cevabını aşağıda verdim:
\"{new_answer}\"

Benzer geçmiş öğrenci cevapları ve puanları şunlardır:
{context}

Bu yeni cevaba 100 üzerinden kaç puan verirdin ve neden?
Cevap:"""
    return prompt

# Yeni öğrenci cevapları (örnek)
new_answers = [
    "Failin kastı yoktur çünkü hata haksızlığı ortadan kaldırır.",
    "İştirak halinde işlenen suçlarda ceza sorumluluğu herkes için farklı değerlendirilir.",
    "Kusur yeteneği olmayan bir kişi ceza sorumluluğu taşımaz."
]

# Prompt'ları üretip kaydet
results = []
for i, ans in enumerate(new_answers):
    similar_df, new_emb = get_similar_answers(ans, top_k=3)
    prompt = generate_feedback_prompt(ans, similar_df)
    results.append({
        "id": i,
        "new_student_answer": ans,
        "prompt": prompt
    })

output_df = pd.DataFrame(results)
output_df.to_csv("RAG/generated_prompts.csv", index=False)
print("✅ Prompts CSV dosyasına kaydedildi: RAG/generated_prompts.csv")